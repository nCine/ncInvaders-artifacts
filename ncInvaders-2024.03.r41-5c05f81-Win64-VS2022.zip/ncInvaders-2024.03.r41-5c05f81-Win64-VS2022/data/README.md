# Data files for the *ncInvaders* example project

## Fonts

Bitmap and descriptor files exported with the "*Bitmap font generator*" from AngelCode: http://www.angelcode.com/products/bmfont/

- **Google Droid Sans** is distributed under the terms of the *Apache License, version 2.0*

## Textures

- All textures are derived from the original **Space Invaders** arcade sprites.

## Icons

- All icons are derived from the original **Space Invaders** arcade sprites.
